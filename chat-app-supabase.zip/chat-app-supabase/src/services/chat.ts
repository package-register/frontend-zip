import { supabase } from '../lib/supabase'

export const getMessages = async (roomId: any) => {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .eq('room_id', roomId)
    .order('created_at', { ascending: false })
    .limit(50)

  if (error) throw error
  return data
}

export const sendMessage = async (roomId: string, message: string, userId: any, imageUrl = null) => {
    const { data, error } = await supabase
      .from('messages') // 确保表名正确
      .insert([{ 
        room_id: roomId, 
        user_id: userId, 
        message: message, // 确保字段名与数据库一致
        image_url: imageUrl 
      }])
      .select()

  if (error) throw error
  return data
}

export const createRoom = async (name: any) => {
  const { data, error } = await supabase.from('rooms').insert([{ name }]).select()
  if (error) throw error
  return data[0]
}