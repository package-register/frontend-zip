import { supabase } from '../lib/supabase'

export const uploadImage = async (file: any, path = 'chat-images/') => {
  const { data, error } = await supabase.storage
    .from('chat-images') // 确保在Supabase Storage中创建了这个bucket
    .upload(`${path}${Date.now()}-${file.name}`, file)

  if (error) throw error
  return data ? data.id : null
}

export const getImageUrl = (path: string) => {
  return supabase.storage.from('chat-images').getPublicUrl(path).data.publicUrl
}