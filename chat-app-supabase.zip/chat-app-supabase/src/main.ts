import { createApp } from 'vue';
import App from './App.vue';
import './assets/tailwind.css';
import { supabase } from "./lib/supabase";
import router from './router';

const app = createApp(App)
app.config.globalProperties.$supabase = supabase

app.use(router)
app.mount('#app')