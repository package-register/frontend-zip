<template>
    <div class="flex flex-col h-screen bg-gray-100">
        <header class="bg-white shadow-md p-4">
            <h1 class="text-xl font-bold">聊天室</h1>
        </header>

        <main class="flex-1 overflow-y-auto p-4 space-y-4">
            <div v-for="message in messages" :key="message.id" class="flex items-start space-x-3">
                <img :src="message.user.avatar_url || 'https://via.placeholder.com/40'" alt="avatar"
                    class="w-10 h-10 rounded-full">
                <div class="flex-1">
                    <div class="flex items-center space-x-2">
                        <span class="font-semibold">{{ message.user.email }}</span>
                        <span class="text-sm text-gray-500">{{ formatDate(message.created_at) }}</span>
                    </div>
                    <p class="mt-2 text-gray-800">
                        {{ message.message }}
                    </p>
                    <img v-if="message.image_url" :src="message.image_url" alt="image"
                        class="mt-2 max-w-full h-auto rounded-md">
                </div>
            </div>
        </main>

        <form @submit.prevent="sendMessage" class="bg-white p-4 shadow-md">
            <div class="flex space-x-2">
                <input type="text" v-model="newMessage" placeholder="输入消息..."
                    class="flex-1 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <input type="file" @change="handleFileChange" accept="image/*" class="hidden" ref="fileInput">
                <button type="button" @click="$refs.fileInput.click()"
                    class="p-2 bg-gray-200 rounded-lg hover:bg-gray-300">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </button>
                <button type="submit" class="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    发送
                </button>
            </div>
        </form>
    </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { getMessages, sendMessage as sendMessageToServer } from '../services/chat'
import { uploadImage } from '../services/storage'

const router = useRouter()
const messages = ref([])
const newMessage = ref('')
const fileInput = ref(null)
const selectedFile = ref(null)

onMounted(async () => {
    // 检查用户是否登录
    const user = JSON.parse(localStorage.getItem('user'))
    if (!user) {
        router.push('/login')
        return
    }

    // 监听新消息
    watchMessages()

    // 加载历史消息
    await loadMessages()
})

const watchMessages = async () => {
    try {
        const user = JSON.parse(localStorage.getItem('user'))
        const { data: channel } = await supabase
            .channel('custom-all-channel')
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'messages' },
                (payload) => {
                    if (payload.new && payload.new.user_id === user.id) return // 避免显示自己发送的消息
                    loadMessages() // 简单起见重新加载所有消息，实际应用中可以优化为只添加新消息
                }
            )
            .subscribe()
    } catch (error) {
        console.error('Error subscribing to messages:', error)
    }
}

const loadMessages = async () => {
    try {
        const user = JSON.parse(localStorage.getItem('user'))
        if (!user) return

        const room = await getRoom() // 实际应用中需要获取当前房间
        if (!room) return

        const { data, error } = await getMessages(room.id)
        if (error) throw error
        messages.value = data || []
    } catch (error) {
        console.error('Error loading messages:', error)
    }
}

const sendMessage = async () => {
    if (!newMessage.value.trim() && !selectedFile.value) return

    try {
        const user = JSON.parse(localStorage.getItem('user'))
        if (!user) return

        let imageUrl = null

        if (selectedFile.value) {
            imageUrl = await uploadImage(selectedFile.value)
        }

        const { data, error } = await sendMessageToServer(
            'room-id',
            newMessage.value,
            user.id,
            imageUrl
        )

        if (error) throw error

        newMessage.value = ''
        selectedFile.value = null
        fileInput.value.value = null

        // 重新加载消息以包含刚发送的消息
        await loadMessages()
    } catch (error) {
        console.error('Error sending message:', error)
    }
}

const handleFileChange = (event) => {
    selectedFile.value = event.target.files[0]
}

const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }
    return new Date(dateString).toLocaleDateString(undefined, options)
}

// 实际应用中需要实现的获取房间函数
const getRoom = async () => {
    // 这里应该返回当前聊天室的信息
    // 为了简化示例，我们返回一个模拟对象
    return { id: 1, name: 'General' }
}
</script>