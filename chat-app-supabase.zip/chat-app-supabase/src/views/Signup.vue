<template>
    <div class="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-500 to-purple-600">
        <div class="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md">
            <h2 class="text-3xl font-bold mb-6 text-center text-gray-800">注册账号</h2>
            <form @submit.prevent="handleSignup" class="space-y-6">
                <div>
                    <label for="email" class="block text-gray-700 text-sm font-semibold mb-2">邮箱</label>
                    <input type="email" id="email" v-model="email"
                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition duration-200"
                        required />
                </div>
                <div>
                    <label for="password" class="block text-gray-700 text-sm font-semibold mb-2">密码</label>
                    <input type="password" id="password" v-model="password"
                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition duration-200"
                        required />
                </div>
                <button type="submit"
                    class="w-full bg-gradient-to-r from-purple-600 to-blue-500 text-white py-2 px-4 rounded-lg hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-purple-500 transition duration-200 font-semibold">
                    注册
                </button>
            </form>
            <p class="mt-6 text-center text-gray-600">
                已有账号？
                <router-link to="/login" class="text-purple-600 hover:text-purple-700 font-semibold">登录</router-link>
            </p>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { supabase } from '../lib/supabase'

const email = ref('')
const password = ref('')
const router = useRouter()

const handleSignup = async () => {
    try {
        const { data, error } = await supabase.auth.signUp({
            email: email.value,
            password: password.value,
        })

        if (error) throw error

        alert('注册成功！请查看您的邮箱进行验证。')
        router.push('/login')
    } catch (error) {
        alert('注册失败: ' + error.message)
    }
}
</script>